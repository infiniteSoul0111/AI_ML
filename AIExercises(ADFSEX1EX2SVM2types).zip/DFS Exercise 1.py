class Node:
    def __init__(self, data):
        self.data = data
        self.children = []

def dfs_search(root, target):
    if root is None:
        return False

    if root.data == target:
        return True

    for child in root.children:
        if dfs_search(child, target):
            return True

    return False

# Create the tree structure from the given graph
A = Node('A')
B = Node('B')
C = Node('C')
D = Node('D')
E = Node('E')
F = Node('F')
G = Node('G')
H = Node('H')

A.children = [B, C, D]
B.children = [E, F]
E.children = [G]
F.children = [H]

# Check if node E is present in the tree
target_node = 'E'
if dfs_search(A, target_node):
    print(f"Node {target_node} is present in the tree")
else:
    print(f"Node {target_node} is not present in the tree")
