import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.utils import shuffle
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler

# Load the dataset
df = pd.read_csv('breast-cancer-data.csv')

# Drop irrelevant or empty columns, such as 'Unnamed: 32' or 'id'
df = df.drop(['Unnamed: 32', 'id'], axis=1)

# Convert 'diagnosis' column to numeric values
df['diagnosis'] = df['diagnosis'].map({'M': -1, 'B': 1})  # 'M' for malignant -> -1, 'B' for benign -> 1

# Handle missing data using SimpleImputer (filling with mean)
imputer = SimpleImputer(strategy='mean')
df_imputed = pd.DataFrame(imputer.fit_transform(df))  # Impute missing values for all columns
df_imputed.columns = df.columns  # Reassign the column names after imputation

# Extract target and features
target = df_imputed['diagnosis']
features = df_imputed.drop(['diagnosis'], axis=1)

# Shuffle and split the data into training and test sets
X, y = shuffle(features.values, target.values, random_state=42)
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.9, random_state=42)

# Feature scaling
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Create and train the SVM classifier with a linear kernel (using all features)
clf_all_features = SVC(kernel='linear')
clf_all_features.fit(X_train, y_train)

# Predict on the test set using the full feature model
y_pred = clf_all_features.predict(X_test)

# Calculate and print the accuracy score
accuracy = accuracy_score(y_test, y_pred)
print(f'Accuracy: {accuracy:.2f}')

# Visualize using only the two selected features: 'radius_mean' (index 0) and 'concavity_mean' (index 8)
X_train_2d = X_train[:, [0, 8]]  # Select 'radius_mean' and 'concavity_mean' for 2D visualization
X_test_2d = X_test[:, [0, 8]]    # Same features for the test set

# Train an SVM model on the two selected features
clf_2d = SVC(kernel='linear')
clf_2d.fit(X_train_2d, y_train)

# Plot the training data
plt.figure(figsize=(10, 8))
plt.scatter(X_train_2d[:, 0], X_train_2d[:, 1], c=y_train, cmap=plt.cm.Paired, marker='o', edgecolor='k', s=100)
plt.title('Training Data with SVM Linear Kernel (2D Visualization)')
plt.xlabel('Radius Mean')
plt.ylabel('Concavity Mean')

# Visualize the decision boundary for the 2D feature space
h = .02  # Step size in the mesh
x_min, x_max = X_train_2d[:, 0].min() - 1, X_train_2d[:, 0].max() + 1
y_min, y_max = X_train_2d[:, 1].min() - 1, X_train_2d[:, 1].max() + 1
xx, yy = np.meshgrid(np.arange(x_min, x_max, h),
                     np.arange(y_min, y_max, h))
Z = clf_2d.predict(np.c_[xx.ravel(), yy.ravel()])
Z = Z.reshape(xx.shape)

# Plot the decision boundary
plt.contourf(xx, yy, Z, alpha=0.3, cmap=plt.cm.Paired)
plt.colorbar()
plt.show()
