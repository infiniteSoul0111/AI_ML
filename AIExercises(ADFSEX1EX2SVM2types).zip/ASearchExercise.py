import heapq

class Node:
    def __init__(self, state, parent=None, g=0, h=0):
        self.state = state
        self.parent = parent
        self.g = g  # Cost from start
        self.h = h  # Heuristic cost to goal

    def __lt__(self, other):
        return (self.g + self.h) < (other.g + other.h)

def astar(graph, start, goal, heuristic):
    open_set = []
    closed_set = set()
    start_node = Node(start)
    heapq.heappush(open_set, start_node)

    while open_set:
        current_node = heapq.heappop(open_set)
        closed_set.add(current_node.state)

        if current_node.state == goal:
            path = []
            while current_node:
                path.append(current_node.state)
                current_node = current_node.parent
            return path[::-1]

        for neighbor, cost in graph[current_node.state].items():
            if neighbor in closed_set:
                continue

            neighbor_node = Node(neighbor, current_node, current_node.g + cost, heuristic(neighbor, goal))
            if neighbor_node not in open_set:
                heapq.heappush(open_set, neighbor_node)
            elif neighbor_node in open_set and neighbor_node.g > current_node.g + cost:
                neighbor_node.g = current_node.g + cost
                neighbor_node.parent = current_node
                heapq.heapify(open_set)

    return None  # No path found

# Define the graph and heuristic function (you can modify the heuristic as needed)
graph = {
    'S': {'A': 6, 'B': 5, 'C': 10},
    'A': {'E': 6},
    'B': {'E': 13, 'D': 7},
    'C': {'D': 6},
    'D': {'F': 2},
    'E': {'F': 4},
    'F': {'G': 1},
    'G': {}
}

def heuristic(node, goal):
    # Straight-line distance heuristic (you can use more accurate heuristics)
    return abs(ord(node) - ord(goal))

# Find the path from 'S' to 'G'
path = astar(graph, 'S', 'G', heuristic)
print(path)
